Para compilar un programa Bugly se pasa un fichero .txt por parámetro
al main del paquete constructorast. 
Se han preparado ejemplos de prueba:
- ejemplo1.txt
- ejemplo2.txt
- ejemplo3.txt
- programa.txt
- ejemploErroresSintacticos.txt
- ejemploErroresVinculacion.txt
- ejemploErroresTipado.txt
- ejemploErroresLexicos.txt
Al principio de cada fichero hay un comentario en el que se explica brevemente lo que muestra el ejemplo.