package errors;

import alex.UnidadLexica;

public class GestionErroresTiny {
	static boolean lexico = false;
	static boolean sint = false;
	static boolean bind = false;
	static boolean tipo = false;
	
   public void errorLexico(int fila, int columna, String lexema) {
     System.out.println("ERROR linea "+fila+" columna "+columna+": Caracter inesperado: "+lexema);
     lexico = true;
   }  
   
   public static boolean fallo_lex() {return lexico;}
   public static boolean fallo_sint() {return sint;}
   public static boolean fallo_bind() {return bind;}
   public static boolean fallo_tipo() {return tipo;}
   
   public void errorSintactico(UnidadLexica unidadLexica) {
     if (unidadLexica.lexema() != null) {
       System.out.println("ERROR linea "+unidadLexica.fila()+" columna "+unidadLexica.columna()+": Elemento inesperado \""+unidadLexica.lexema()+"\"");
     } else {
       System.out.println("ERROR linea "+unidadLexica.fila()+" columna "+unidadLexica.columna()+": Elemento inesperado");
     }
     sint = true;
   }
   
   public static void error_bind() {bind = true;}
   public static void error_tipo() {tipo = true;}
}
