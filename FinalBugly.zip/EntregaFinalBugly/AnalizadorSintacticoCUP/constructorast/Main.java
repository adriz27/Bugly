package constructorast;

import java.io.FileInputStream;
import java.io.FileWriter;
import java.io.InputStreamReader;
import java.io.PrintWriter;
import java.io.Reader;
import java.util.HashMap;

import alex.AnalizadorLexicoTiny;
import asint.AnalizadorSintacticoTinyE;
import ast.*;
import errors.GestionErroresTiny;

public class Main {
   public static void main(String[] args) throws Exception {
     Reader input = new InputStreamReader(new FileInputStream(args[0]));
	 AnalizadorLexicoTiny alex = new AnalizadorLexicoTiny(input);
	 //AnalizadorSintacticoTinyE asint = new AnalizadorSintacticoTinyE(alex);
	 ConstructorASTExp constructorast = new ConstructorASTExp(alex);
	 //asint.parse();
	 //if (GestionErroresTiny.fallo_lex() || GestionErroresTiny.fallo_sint()) {System.exit(1);}
	 ASTNode programa = ((ASTNode) constructorast.parse().value);
	 if (GestionErroresTiny.fallo_lex() || GestionErroresTiny.fallo_sint()) {System.exit(1);}
	 //System.out.println(z);
	 
	 programa.bind(new TablaSimbolos());
	 if (GestionErroresTiny.fallo_bind()) {System.exit(1);}
	 
	 programa.chequea(new HashMap<String, String>());
	 if (GestionErroresTiny.fallo_tipo()) {System.exit(1);}
	 
	 String code = programa.generateCode();
	 //System.out.println(code);
     FileWriter fichero = new FileWriter("./Documentaci�n Laboratorio WebAssembly-20220504/prueba.wat");
     PrintWriter pw = new PrintWriter(fichero);
     pw.print(code);
     fichero.close();
     System.out.println("C�digo generado exitosamente en prueba.wat");
 }
}   
 
