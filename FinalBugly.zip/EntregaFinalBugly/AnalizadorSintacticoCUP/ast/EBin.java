package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class EBin extends E {
   private E opnd1;
   private E opnd2;
   private KindE kind;
   private String subt;
   
   public EBin(KindE kinde, E opnd1, E opnd2) {
     this.opnd1 = opnd1;
     this.opnd2 = opnd2;
     this.kind = kinde;
   }
   public E opnd1() {return opnd1;}
   public E opnd2() {return opnd2;}    
   public KindE kind() {return kind;}
   
   public String toString() {
	   String s = null;
	   switch(this.kind) {
	   
	   case SUMA:
		   s= "suma("+opnd1().toString()+","+opnd2().toString()+")";
		   break;
	   
	   case MUL:
		   s= "mul("+opnd1().toString()+","+opnd2().toString()+")";
		   break;
		case DISTINTO:
			s= "distinto("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case IGUALDAD:
			s= "igualdad("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case  MAYORIGUAL:
			s= "mayorigual("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case MENORIGUAL :
			s= "menorigual("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case MAYOR:
			s= "mayor("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case MENOR:
			s= "menor("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case OR:
			s= "or("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case RESTA:
			s= "resta("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case AND:
			s= "and("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case MOD:
			s= "mod("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case DIV:
			s= "div("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case POT:
			s= "pot("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case CAMPO:
			s= "campo("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		case ACCESO:
			s= "acceso("+opnd1().toString()+","+opnd2().toString()+")";
			break;
		
		default:
			break;
			   
		   
	   }
	return s;
   }

	public void bind(TablaSimbolos ts) {
		opnd1.bind(ts);
		opnd2.bind(ts);		
	}
	
	public void chequea(Map<String, String> tt) {
		opnd1.chequea(tt);
		opnd2.chequea(tt);
		if(this.kind == KindE.CAMPO) {
			String[] op1 = opnd1.type().split(" ");
			String[] op2 = opnd2.type().split(" ");
			if(!(op1[0].equals("struct"))){
				System.out.println("Error en acceso a campo: El primer operando (" + opnd1 + ") no es un identificador de struct");
				GestionErroresTiny.error_tipo();
			}
			if(!(op2[0].equals("campo"))) {
				System.out.println("Error en acceso a campo: El segundo operando (" + opnd2 + ") no es un identificador de campo");
				GestionErroresTiny.error_tipo();
			}
			
			
		}
		else if(this.kind == KindE.ACCESO) {
			String[] op1 = opnd1.type().split(" ");
			if(!(op1[0].equals("array") && opnd2.type().equals("int"))) {
				if(!(op1[0].equals("array"))) {
					GestionErroresTiny.error_tipo();
					System.out.println("Error en acceso a array: El primer operando (" + opnd1 + ") no es un identificador de array");
				}else {
					System.out.println("Error en acceso a array: El segundo operando (" + opnd2 + ") no es una expresi�n entera");
					GestionErroresTiny.error_tipo();
				}
			}
			else {
				subt = op1[2];
				for (int i = 3; i < op1.length; i++) {
					subt = subt + " " + op1[i];
				}
			}
		}
		else if(!opnd1.type().equals(opnd2.type())) {
			System.out.println("Error en expresi�n: Los tipos de " + opnd1 + " y " + opnd2 + " no coinciden");
			GestionErroresTiny.error_tipo();
		}
		else if(kind == KindE.SUMA || kind == KindE.MUL || kind == KindE.MOD || kind == KindE.DIV || kind == KindE.POT || kind == KindE.RESTA || kind == KindE.MAYOR ||kind == KindE.MENOR ||kind == KindE.MAYORIGUAL ||kind == KindE.MENORIGUAL) {
			if(!(opnd1.type().equals("int") && opnd2.type().equals("int"))) {
				System.out.println("Error en expresi�n aritm�tica: " + opnd1 + " y " + opnd2 + " deben ser expresiones enteras");
				GestionErroresTiny.error_tipo();
			}
		}
		else if ((kind == KindE.AND || kind == KindE.OR) && !(opnd1.type().equals("bool") && opnd2.type().equals("bool"))) {
			System.out.println("Error en expresi�n booleana: " + opnd1 + " y " + opnd2 + " deben ser expresiones booleanas");
			GestionErroresTiny.error_tipo();
		}
	}
	
	public String type() {
		if(this.kind == KindE.CAMPO) {
			String t = opnd2.type();
			return t.substring(6);
		}
		else if(kind == KindE.ACCESO) {
			return subt;
		}
		else if(kind == KindE.SUMA || kind == KindE.MUL || kind == KindE.MOD || kind == KindE.DIV || kind == KindE.POT || kind == KindE.RESTA ) {
			return "int";
		}
		else {
			return "bool";
		}
	}
	
	public String generateCode() {
		String s = null;
		if (this.kind != KindE.ACCESO && this.kind != KindE.CAMPO) {
	    s = opnd1.generateCode();	
		s += opnd2.generateCode();
		switch(this.kind) {
		   case SUMA:
			   s += "i32.add \n";
			   break;
		   case MUL:
			   s += "i32.mul \n";
			   break;
			case DISTINTO:
				s += "i32.eq \n";
				s += "i32.eqz \n";
				break;
			case IGUALDAD:
				s += "i32.eq \n";
				break;
			case  MAYORIGUAL:
				s += "i32.ge_s \n";
				break;
			case MENORIGUAL :
				s += "i32.le_s \n";
				break;
			case MAYOR:
				s += "i32.gt_s \n";
				break;
			case MENOR:
				s += "i32.lt_s \n";
				break;
			case OR:
				s += "i32.or \n";
				break;
			case RESTA:
				s += "i32.sub \n";
				break;
			case AND:
				s += "i32.and \n";
				break;
			case MOD:
				s += "set_local $temp2\n"+
					 "set_local $temp1\n"+
					 "get_local $temp1\n"+
					 "get_local $temp2\n"+
					 "get_local $temp1\n"+
					 "get_local $temp2\n"+
					 "i32.div_s\n"+
					 "i32.mul\n"+
					 "i32.sub\n";
				break;
			case DIV:
				s += "i32.div_s \n";
				break;
			case POT:
				
				break;
		default:
			break;
		};
		}else if (this.kind == KindE.CAMPO) {
				s = opnd1.generateCode_dir();
				s += "i32.const "+ opnd2.getNode().getDelta()*4 + "\n";
				s += "i32.add\n";
				s += "i32.load\n";
		}
		else if (this.kind == KindE.ACCESO) {
				s = opnd1.generateCode_dir();
				s += "i32.const " + Tipo.espacio(subt)*4 + "\n";
				s += opnd2.generateCode();
				s += "i32.mul \n";
				s += "i32.add \n";
				s += "i32.load \n";
		}
		return s;
	}
	
	public String generateCode_dir() {
		String s = null;
		if (this.kind == KindE.CAMPO) {
			s = opnd1.generateCode_dir();
			s += "i32.const "+ opnd2.getNode().getDelta()*4 + "\n";
			s += "i32.add\n";
		}
		else if (this.kind == KindE.ACCESO) {
			s = opnd1.generateCode_dir();
			s += "i32.const " + Tipo.espacio(subt)*4 + "\n";
			s += opnd2.generateCode();
			s += "i32.mul \n";
			s += "i32.add \n";
		}
		else {
			s = "";
		}
	return s;
	}
}
   
