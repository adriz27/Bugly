package ast;

import java.util.Map;

public class TAlias extends T {
	private Id id;
	private Tipo t;
	public TAlias( Id id, Tipo t) {
		this.id = id;
		this.t = t;
	}
	public String id() {return id.toString();}
	public String tipo() {return t.toString();}
	
	public String toString() {
		return "alias("+id()+","+tipo()+")";
	}

	public KindT kind() {
		return KindT.ALIAS;
	}
	
	public void bind(TablaSimbolos ts) {
		ts.insertaId(id, this);
	}
	
	public void chequea(Map<String, String> tt) {
		String tipo = t.tipo();
		if(tt.containsKey(tipo)) {tipo = tt.get(tipo);}
		tt.put(id.id(), tipo);
	}
	
	public String type() {
		return t.tipo();
	}


}
