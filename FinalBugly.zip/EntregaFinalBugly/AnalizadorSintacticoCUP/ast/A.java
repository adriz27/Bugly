package ast;

import java.util.Map;

public abstract class A extends Valor implements ASTNode  {
    public abstract KindA kind();
    public Valor val() {throw new UnsupportedOperationException("elemento");} 
    public A arr() {throw new UnsupportedOperationException("elementos");} 
    public NodeKind nodeKind() {return NodeKind.ARRAY;}
    //public String toString() {return "";}
    //public void bind(TablaSimbolos ts) {}
    public void chequea(Map<String, String> tt) {}
    public String type() {return null;}
    public String generateCode() {return null;}
}
