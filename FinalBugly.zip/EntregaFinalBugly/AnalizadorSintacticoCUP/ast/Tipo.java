package ast;

public class Tipo{
	  private String t;
	  private boolean punt;
	  
	  public Tipo(String t) {
		  this.t = t;
	  }
	  
	  public Tipo(String t, boolean b) {
		  this.t = t;
		  this.punt = b;
	  }
	  
	  public String tipo() {
		  String s = "";
		  if(punt) {s = "p ";}
		  s = s + t;
		  return s;
	  }
	  
	  
	  public String getT() {
		  return t;
	  }
	  
	  public String toString() {
		  String s = "";
		  if (punt == true) {
			  s = s + "punt(" + t + ")";
		  }
		  else {
			  s = t;
		  }
		  return s;
	  }

	public boolean punt() {
		return punt;
	}

	public static int espacio(String tipo) {
		if(tipo.charAt(0) == 'p') {return 1;}
		else {
			switch (tipo) {
			case "int":
				return 1;
			case "bool":
				return 1;
			default:
				String[] s = tipo.split(" ");
				if(s[0].equals("array")) {
					String subt = s[2];
					for (int i = 3; i < s.length; i++) {
						subt += " " + s[i];
					}
					return Integer.parseInt(s[1]) * Tipo.espacio(subt);
				}else if (s[0].equals("struct")) {
					int esp = 0;
					String[] campos = tipo.substring(7).split(", ");
					for (int i = 0; i < campos.length; i++) {
						
						esp += Tipo.espacio(campos[i]);
						
					}
					return esp;
				}
				return 1;
			}
		}
	}

	public String generateCode() {
		if(punt) {return "i32";}
		switch (t) {
		case "int":
			return "i32";
		case "bool":
			return "i32";
		default:
			return "";
		}
	}

	public void updateTipo(String tipo) {
		t = tipo;
	}
}
