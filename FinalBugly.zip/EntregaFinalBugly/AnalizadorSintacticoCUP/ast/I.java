package ast;

public abstract class I implements ASTNode {
	public abstract KindI kind();
    public String id() {throw new UnsupportedOperationException("id");} 
    public Tipo tipo() {throw new UnsupportedOperationException("tipo");}
    public E expresion() {throw new UnsupportedOperationException("expresion");}
    public E var() {throw new UnsupportedOperationException("var");}
    public I ins() {throw new UnsupportedOperationException("instrucciones");}
    public I ins1() {throw new UnsupportedOperationException("instrucciones");}
    public I ins2() {throw new UnsupportedOperationException("instrucciones");}
    
    public NodeKind nodeKind() {return NodeKind.INSTRUCTION;}
    //public String toString() {return "";}
    //public void bind(TablaSimbolos ts) {}
    public void chequea(Tabla tt) {}
    public String type() {return null;}
	protected String retorno() {
		return "void";
	}
	//public String generateCode() {return "";}
	public int calcular_espacio(int e) {return e;}
	public int getDelta() {return 0;}
}
