package ast;

import java.util.Map;

public interface ASTNode {
    //public void type(); // for the future
    public void bind(TablaSimbolos ts);
    public String generateCode(); // for the future
    public NodeKind nodeKind();
    public String toString();
	public void chequea(Map<String, String> tt);
	public String type();
	public int getDelta();
}
