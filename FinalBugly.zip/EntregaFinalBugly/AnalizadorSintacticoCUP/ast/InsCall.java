package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class InsCall extends I{
	private E llamada;
	
	public InsCall(E llamada) {
		this.llamada = llamada;
	}
	
	public E e() {return llamada;}
	
	public String toString() {
		return e().toString();
	}
	public KindI kind() {
		return KindI.CALL;
	}

	public void bind(TablaSimbolos ts) {
		llamada.bind(ts);
	}
	
	public void chequea(Map<String, String> tt) {
		llamada.chequea(tt);
		if(!llamada.type().equals("void")) {
			System.out.println("Error en llamada a funci�n: La funci�n tiene tipo de retorno " + llamada.type());
			GestionErroresTiny.error_tipo();
		}
	}
	
	public String generateCode() {
		return llamada.generateCode();
	}
}
