package ast;

import java.util.Map;

public class FArg extends F{
	private Tipo t;
	private Id id;
	private FArg args;
	int delta;
	
	public FArg (Tipo t, Id id, FArg args) {
		this.t = t;
		this.id = id;
		this.args = args;
	}
	public FArg (Tipo t, Id id) {
		this.t = t;
		this.id = id;
	}
	
	public String id() {return this.id.toString();} 
    public String tipo() {return this.t.toString();} 
    public FArg argumentos() {return this.args;} 
	
	public String toString() {
		String s = null;
		s = "arg(" + tipo()+","+id()+")";
		if (args != null) {
		   s = s +","+argumentos().toString();
		}
		return s;
	}
	
	public void bind(TablaSimbolos ts) {
		ts.insertaId(id, this);
		if(args != null) {
			args.bind(ts);
		}
	}
	
	public void prebind(TablaSimbolos ts) {}
	
	public String tipos() {
		String s = t.tipo();
		if(args != null) {
			s = s + ", " + args.type();
		}
		return s;
	}
	
	public void chequea(Map<String, String> tt) {
		String tipo = t.tipo();
		if(tt.containsKey(tipo)) {t.updateTipo(tt.get(tipo));}
		if(args!= null) {args.chequea(tt);}
	}
	
	public String type() {
		return t.tipo();
	}
	
	public int calcular_espacio(int esp) {
		delta = esp;
		esp += Tipo.espacio(t.tipo());
		if(args != null) {esp = args.calcular_espacio(esp);}
		return esp;
	}
	public String generateCode() {
		String s = "";
		if(args != null) {s += args.generateCode();}
		if (t.tipo().equals("int") || t.tipo().equals("bool")){
			s += guardarEntero(delta*4 +8);
		}else {
			String[] tip = t.tipo().split(" ");
			if (tip[0].equals("array")) {
				int tam = Integer.parseInt(tip[1]);
				String subt = tip[2];
				for (int i = 3; i< tip.length;i++) {
					subt += " " + tip[i];
				}
				s+=guardarArray(tam,subt, delta*4+8);
			}else if(tip[0].equals("struct")) {
				String[] ss = t.tipo().substring(7).split(", ");
				int tamano = Tipo.espacio(t.tipo());
				s += guardarStruct(ss, delta*4+8, tamano);
			
			}
		}
		return s;
	}
	
	private String guardarEntero(int desplz) {
		
		String s = "   set_local $temp\r\n" + 
				"   get_global $SP\r\n" + 
				"   get_local $temp\r\n" + 
				"   i32.store offset=" + (desplz) + "\n";
		return s;
	}
	
	private String guardarArray(int tam, String subt, int desplz) {
		String s ="";
		if (subt.equals("int") || subt.equals("bool")){
			for(int i = tam-1; i>=0; i--) {
				s += guardarEntero(i*4 + desplz);
			}
		}else {
			String[] tip = subt.split(" ");
			if (tip[0].equals("array")) {
				int tam1 = Integer.parseInt(tip[1]);
				String subt1 = tip[2];
				for (int i = 3; i< tip.length;i++) {
					subt += " " + tip[i];
				}
				for(int i = tam-1; i>=0; i--) {
					s+=guardarArray(tam1,subt1, i*Tipo.espacio(subt)*4 +desplz);
				}
			}else if(tip[0].equals("struct")) {
				String[] sss = subt.substring(7).split(", ");
				for(int i = tam-1; i >=0; i--) {
					int tamano = Tipo.espacio(subt);
					s += guardarStruct(sss,  desplz + i*Tipo.espacio(subt)*4, tamano);
				}
			}
		}
		
		return s;
	}

	private String guardarStruct(String[] ss,int desplz, int tamano) {
		String s = "";
		int tam = tamano;
		for (int i = ss.length -1; i >= 0; i--) {
			tam -= Tipo.espacio(ss[i]);
			if(ss[i].equals("int") || ss[i].equals("bool")) {
				s+= guardarEntero(desplz+tam*4);
			}else {
				String t[] = ss[i].split(" ");
				if (t[0].equals("array")) {
					int tam1 = Integer.parseInt(t[1]);
					String subt = t[2];
					for (int j = 3; j< t.length;j++) {
						subt += " " + t[j];
					}
					s+=guardarArray(tam1,subt,desplz+tam*4);
					
				}else if(t[0].equals("struct")) {
					String[] sss = ss[i].substring(7).split(", ");
					int tamano1 = Tipo.espacio(ss[i]);
					s += guardarStruct(sss, desplz+tam*4, tamano1);
					
				}
			}
			
		}
		return s;
	}
	
	public int getDelta() {
		return delta;
	}
	   
}
