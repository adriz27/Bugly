package ast;

public abstract class E extends Valor implements ASTNode  {
    public abstract KindE kind();
    public E opnd1() {throw new UnsupportedOperationException("opnd1");} 
    public E opnd2() {throw new UnsupportedOperationException("opnd2");} 
    public String num() {throw new UnsupportedOperationException("num");}
    public String id() {throw new UnsupportedOperationException("id");}
    public EParams params() {throw new UnsupportedOperationException("parametros");}
    public String param1() {throw new UnsupportedOperationException("parametro");}
    public NodeKind nodeKind() {return NodeKind.EXPRESSION;}
    //public String toString() {return "";}
    //public void bind(TablaSimbolos ts) {}
    public void chequea(Tabla tt) {}
    //public String type() {return null;}
    //public String generateCode() {return null;}
    public int getDelta() {return 0;}
    public ASTNode getNode() {return null;}
	public String generateCode_dir() {
		return "";
	}
}
