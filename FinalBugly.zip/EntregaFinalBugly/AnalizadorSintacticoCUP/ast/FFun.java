package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class FFun extends F{
	private Tipo t;
	private Id id;
	private FArg args;
	private I instrs;
	
	public FFun (Id id, I instrs) {
		this.id = id;
		this.instrs = instrs;
	}
	public FFun (Id id, FArg args, I instrs) {
		this.args = args;
		this.id = id;
		this.instrs = instrs;
	}
	public FFun (Tipo t, Id id, I instrs) {
		this.t = t;
		this.id = id;
		this.instrs = instrs;
	}
	public FFun (Tipo t, Id id, FArg args, I instrs) {
		this.t = t;
		this.args = args;
		this.id = id;
		this.instrs = instrs;
	}
	
	public String id() {return this.id.toString();}
    public String tipo() {return this.t.toString();} 
    public FArg argumentos() {return this.args;} 
    public I instrucciones() {return this.instrs;} 
    
    public String toString() {
		 String s = "";
		 if (t == null) {
			 s = "funvoid("+id()+",(";
			 if(args != null) {
				 s = s + argumentos().toString()+"),(";
			 }
			 if(instrs != null) {
				 s = s + instrucciones().toString();
			 }
			 s = s +"))";
		 }
		 else {
			 s = "fun("+id()+",(";
			 if(args != null) {
				 s = s + argumentos().toString()+"),(";
			 }
			 if(instrs != null) {
				 s = s + instrucciones().toString();
			 }
			 s = s +"))";
		 }
		 return s;
	   }
    public void prebind(TablaSimbolos ts) {
		ts.insertaId(id, this);		
	}
    
	public void bind(TablaSimbolos ts) {
		ts.abreBloque();
		if(args != null) {
			args.bind(ts);
		}
		if(instrs != null) {
			instrs.bind(ts);
		}
		ts.cierraBloque();
	}
	
	public String type() {
		if(t == null) {return "void";}
		return t.tipo();
	}
	
	public void chequea(Map<String, String> tt) {
		if (t != null) {
			String tipo = t.tipo();
			if(tt.containsKey(tipo)) {tipo = tt.get(tipo);}
			t.updateTipo(tipo);
		}
		if (args != null) {
			args.chequea(tt);
		}
		if(instrs != null) {
			instrs.chequea(tt);
			if(t == null) {
				if(!instrs.retorno().equals("void")) {
					System.out.println("Error en tipo de retorno: La funci�n " + id.id() + " se ha definido como void");
					GestionErroresTiny.error_tipo();
				}
			}
			else {
				if(!instrs.retorno().equals(t.tipo())) {
					System.out.println("Error en tipo de retorno: La funci�n " + id.id() + " no devuelve " + t.tipo());
					GestionErroresTiny.error_tipo();
				}
			}
		}
		else {
			if(t != null) {
				System.out.println("Error en la definici�n de la funci�n " + id.id() + ": El tipo de retorno especificado no es v�lido");
				GestionErroresTiny.error_tipo();
			}
		}
	}
	
	public String generateCode() {
		String s = "(func $" + id.id();
		if (t != null) {
			s += " (result " + t.generateCode() + ")";
		}
		s += "\n(local $temp i32)\n(local $localsStart i32)\n";
		
		int esp = calcular_espacio(0);
		if (instrs != null) {esp = instrs.calcular_espacio(esp);}
		s += "i32.const " + (esp*4 + 8) +"\n";
		s += "call $reserveStack\n"
		  +  "   set_local $temp\r\n"
				+ "   get_global $MP\r\n"
				+ "   get_local $temp\r\n"
				+ "   i32.store\r\n"
				+ "   get_global $MP\r\n"
				+ "   get_global $SP\r\n"
				+ "   i32.store offset=4\r\n"
				+ "   get_global $MP\r\n"
				+ "   i32.const 8\r\n"
				+ "   i32.add\r\n"
				+ "   set_local $localsStart\n";
		if (instrs != null) {
			s += instrs.generateCode();
		}
		s += "call $freeStack\n";
		return s + ")\n";
	}
	public int calcular_espacio(int esp) {
		if(args != null) {return args.calcular_espacio(esp);}
		return 0;
	}
	public String codigoparams() {
		String s = "";
		if(args != null) {s += args.generateCode();}
		return s;
	}
}
