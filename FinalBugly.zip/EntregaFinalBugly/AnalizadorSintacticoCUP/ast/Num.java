package ast;

import java.util.Map;

public class Num extends E {
	private String v;
	
	public Num(String v) {
		this.v = v;
	}
	public String num() {return v;}
	public KindE kind() {return KindE.ENT;}   
	public String toString() {return v;}

	public void bind(TablaSimbolos ts) {
		
	}
	@Override
	public void chequea(Map<String, String> tt) {
		// TODO Auto-generated method stub
		
	} 
	public String type() {
		return "int";
	}
	@Override
	public String generateCode() {
		return "i32.const " + v + "\n";
	}
	
}
