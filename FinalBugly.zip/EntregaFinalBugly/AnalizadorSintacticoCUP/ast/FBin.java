package ast;

import java.util.Map;

public class FBin extends F{
	private F f1;
	private F f2;
	public FBin(F f1,  F f2) {
		this.f1 = f1;
		this.f2 = f2;
	}
	public FBin(F f1) {
		this.f1 = f1;
	}
	 public String toString() {
		 String s = null;
		 if (f2 != null) {
		   s= f1.toString()+","+f2.toString();
		 }
		 else {
		   s =  f1.toString();
		 }
		 return s;
	   }
	public void bind(TablaSimbolos ts) {
		f1.bind(ts);
		if(f2 != null) {
			f2.bind(ts);
		}
	}
	
	public void prebind(TablaSimbolos ts) {
		f1.prebind(ts);
		if(f2 != null) {
			f2.prebind(ts);
		}
	}
	
	public String type() {
		return null;
	}
	
	public void chequea(Map<String, String> tt) {
		f1.chequea(tt);
		if(f2 != null) {
			f2.chequea(tt);
		}
	}
	
	public String generateCode() {
		String s = f1.generateCode();
		if(f2 != null) {
			s += f2.generateCode();
		}
		return s;
	}
}
