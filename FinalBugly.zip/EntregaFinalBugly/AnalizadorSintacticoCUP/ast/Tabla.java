package ast;
import java.util.HashMap;
import java.util.Map;

public class Tabla {
	private Map<String,ASTNode> tabla;
	
	public Tabla() {
		this.tabla = new HashMap<String,ASTNode>();
	}

	public ASTNode getNode(String id) {
		return tabla.get(id);
	}

	public void setIdNode(String id, ASTNode node) {
		tabla.put(id, node);
	}
	
	
}