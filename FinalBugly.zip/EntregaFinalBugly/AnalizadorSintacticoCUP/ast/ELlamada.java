package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class ELlamada extends E {
	private Id id;
	private EParams params;
	
	public ELlamada (Id id, EParams params) {
		this.id = id;
		this.params = params;
	}
	public ELlamada (Id id) {
		this.id = id;
	}
	public String id() {return id.toString();}
	public EParams params() {return params;}
	
	public String toString() {
		String s = "llamada(" + id();
		if (this.params != null) {
			s = s + ","+params().toString();
		}
		s = s + ")";
		return s;
	}
	
	
	public KindE kind() {
		return KindE.LLAMADA;
	}
	
	public void bind(TablaSimbolos ts) {
		id.bind(ts);
		if (params != null) {
			params.bind(ts);
		}
	}
	public void chequea(Map<String, String> tt) {
		if(params != null) {
			params.chequea(tt);
			if(! params.tipos().equals(((FFun) id.getNode()).argumentos().tipos())){
				System.out.println("Error en la llamada a funci�n " + id.id() + ": El tipo de los argumentos no coincide con el tipo de los par�metros");
				GestionErroresTiny.error_tipo();
			}
		}
	}
	
	public String type() {
		return id.getNode().type();
	}
	
	public String generateCode() {
		if(id.id().equals("read")) {
			return params.generateCode_dir()
					+ "call $read\n"
					+ "i32.store\n";
		}
		else {
			String s = "";
			if (params != null) {
				s += params.generateCode();
			}
			FFun def = ((FFun) id.getNode());
			s += def.codigoparams();
			s += "call $" + id.id() + "\n";
			return s; 
		}
	}
	
}
