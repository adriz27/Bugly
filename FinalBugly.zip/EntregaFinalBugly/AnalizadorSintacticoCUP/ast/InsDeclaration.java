package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class InsDeclaration extends I{
	private Tipo tipo;
	private Id id;
	private int delta;
	
	public InsDeclaration(Tipo tipo, Id id) {
		this.id = id;
		this.tipo = tipo;
	}

	public Tipo tipo() {return tipo;}
	
	public String toString() {
		return "decl("+ tipo.toString() +","+id.toString()+")";
	}
	
	public KindI kind() {
		return KindI.DECL;
	}
	public void bind(TablaSimbolos ts) {
		if(tipo.getT().equals("int") || tipo.getT().equals("bool") || ts.buscaSt(tipo.getT()) != null) {
			
			if(ts.buscaId_ambito(id) == null) {
				ts.insertaId(id, this);
			}
			else{
				System.out.println("Identificador ya definido en este ambito: " + id.toString());
				GestionErroresTiny.error_bind();
			}
		}
		else {
			System.out.println("Tipo no definido: " + tipo.getT());
			GestionErroresTiny.error_bind();
		}
	}
	
	public void chequea(Map<String, String> tt) {
		String t = tipo.tipo();
		if(tt.containsKey(t)) {
			tipo.updateTipo(tt.get(t));
		}
	}
	
	public String type() {
		return tipo.tipo();
	}
	
	public int calcular_espacio(int e){
		delta = e;
		return e + Tipo.espacio(tipo.tipo());
	}

	public int getDelta() {
		return delta;
	}

	public String generateCode() {
		return "";
	}
}
