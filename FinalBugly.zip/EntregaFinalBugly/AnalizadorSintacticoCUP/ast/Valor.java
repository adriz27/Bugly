package ast;

public abstract class Valor implements ASTNode {
	//public String toString() {return "";}
	//public void bind(TablaSimbolos ts) {}
    public void chequea(Tabla tt) {}
    //public String type() {return null;}
    //public String generateCode() {return null;}
    public int getDelta() {return 0;}
	

}
