package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class Id extends E{
	private String v;
	private ASTNode n;
	
	public Id(String v) {
	  this.v = v;   
	}
	public String id() {return v;}
	public KindE kind() {return KindE.ID;}   
	public String toString() {return v;}
	
	public void bind(TablaSimbolos ts) {
		n = ts.buscaId(this);
		if (n == null) {
			GestionErroresTiny.error_bind();
			System.out.println("Identificador no declarado: " + v);
		}
	}
	public ASTNode getNode() {
		return n;
	}
	
	public void chequea(Map<String, String> tt) {}
	
	public String type() {
		return n.type();
	}
	
	public String generateCode() {
		String s = "";
		if (n.type().equals("int") || n.type().equals("bool")){
			s += cargarEntero(n.getDelta()*4); 
		}else {
			String[] t = n.type().split(" ");
			if (t[0].equals("array")) {
				int tam = Integer.parseInt(t[1]);
				String subt = t[2];
				for (int i = 3; i< t.length;i++) {
					subt += " " + t[i];
				}
				s+=cargarArray(tam,subt,n.getDelta()*4);
				
			}else if(t[0].equals("struct")) {
				String[] ss = n.type().substring(7).split(", ");
				s += cargarStruct(ss, n.getDelta()*4);
				
			}
		}
		return s;
		
	}
	
	private String cargarEntero(int desplz) {
		String s = "";
		s += "i32.const " + desplz +"\n";
		s += "get_local $localsStart\r\n";
		s += "i32.add\n" ;
		s += "i32.load\n";
		return s;
	}
	
	private String cargarArray(int tam, String subt, int desplz ) {
		String s = "";
		if (subt.equals("int") || subt.equals("bool")){
			for(int i = 0; i < tam; i++) {
				s += cargarEntero(desplz + 4 * i);
			}
		}
		else {
			String[] t = subt.split(" ");
			if (t[0].equals("array")) {
				int tam1 = Integer.parseInt(t[1]);
				String subt1 = t[2];
				for (int i = 3; i< t.length;i++) {
					subt1 += " " + t[i];
				}
				for(int i = 0; i < tam; i++) {
					s += cargarArray(tam1, subt1, desplz + i*Tipo.espacio(subt)*4);
				}
			}else if(t[0].equals("struct")) {
				String[] sss = subt.substring(7).split(", ");
				for(int i = 0; i < tam; i++) {
					s += cargarStruct(sss,  desplz + i*Tipo.espacio(subt)*4);
				}
			}
		}
		return s;
	}
	private String cargarStruct(String[] ss, int desplz) {
		String s = "";
		int tam = 0;
		for (int i = 0; i< ss.length; i++) {
			if(ss[i].equals("int") || ss[i].equals("bool")) {
				s+= cargarEntero(desplz+tam*4);
			}else {
				String t[] = ss[i].split(" ");
				if (t[0].equals("array")) {
					int tam1 = Integer.parseInt(t[1]);
					String subt = t[2];
					for (int j = 3; j< t.length;j++) {
						subt += " " + t[j];
					}
					s+=cargarArray(tam1,subt,desplz+tam*4);
					
				}else if(t[0].equals("struct")) {
					String[] sss = ss[i].substring(7).split(", ");
					s += cargarStruct(sss, desplz+tam*4);
					
				}
			}
			tam += Tipo.espacio(ss[i]);
		}
		return s;
	}
	public String generateCode_dir() {
		int d = n.getDelta() * 4;
		String s = "i32.const " + d +"\n";
		s += "get_local $localsStart\r\n";
		s += "i32.add\n";
		return s;
	}
	
}
