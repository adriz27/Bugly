package ast;

import java.util.Map;

public class TStruct extends T{
	private Id id;
	private TCampoBin c;
	private String tipo;
	
	public TStruct( Id id, TCampoBin c) {
		this.id = id;
		this.c = c;
	}
	public String id() {return this.id.toString();}
	public TCampoBin campo() {return this.c;}
		
	public String toString() {
		return "struct("+id()+",("+campo().toString()+"))";
	}

	public KindT kind() {
		return KindT.STRUCT;
	}
	
	public void bind(TablaSimbolos ts) {
		ts.insertaId(id, this);
		c.bind(ts);
	}
	
	public void chequea(Map<String, String> tt) {
		c.chequea(tt);
		tipo = "struct " + c.tipos();
		tt.put(id.id(), tipo);
	}
	
	public String generateCode() {
		int e = 0;
		e = c.calcular_espacio(e);
		
		return "";
	}
	
	public String type() {
		return tipo;
	}
}
