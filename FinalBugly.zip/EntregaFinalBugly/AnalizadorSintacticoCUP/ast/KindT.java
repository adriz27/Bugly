package ast;

public enum KindT {
	ALIAS, STRUCT, ENUM, ARRAY, CAMPO, ELEMENUM
}
