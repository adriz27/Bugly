package ast;

import java.util.Map;

public class Program implements ASTNode{
	private T dt;
	private F df;
	private I ins;
	public Program(T t, F f, I ins) {
		this.dt = t;
		this.df = f;
		this.ins = ins;
	}
	public Program(F f, I ins) {
		this.df = f;
		this.ins = ins;
	}
	public Program(T t, I ins) {
		this.dt = t;
		this.ins = ins;
	}
	public Program(I ins) {
		this.ins = ins;
	}

	public T dt() {return dt;}
	public I ins() {return ins;}
	public F df() {return df;}
	
	public String toString() {
		String s = "program(";
		if (dt != null) {
			s = s + "deftipos(" + dt().toString()+"),";
		}
		if (df != null) {
			s = s + "deffunc(" + df().toString()+"),";
		}
		if (ins != null) {
			s = s + "inst(" + ins().toString() + ")";
		}
		s = s + ")";
		return s;
	}
	public NodeKind nodeKind() {
		return NodeKind.PROGRAMA;
	}
	public void bind(TablaSimbolos ts) {
		ts.abreBloque();
		FFun fread = new FFun(new Tipo("void"), new Id("read"), new FArg(new Tipo("int"), new Id("i")), null);
		FFun fwrite = new FFun(new Tipo("void"), new Id("write"), new FArg(new Tipo("int"), new Id("i")), null);
		ts.insertaId(new Id("read"), fread);
		ts.insertaId(new Id("write"), fwrite);
		if (dt != null) {dt.bind(ts);}
		if (df != null) {df.prebind(ts);}
		if (df != null) {df.bind(ts);}
		if (ins!= null) {ins.bind(ts);}
		ts.cierraBloque();
	}

    public String type() {return null;}
	
	public void chequea(Map<String, String> tt) {
		if (dt != null) {dt.chequea(tt);}
		if (df != null) {df.chequea(tt);}
		if (ins!= null) {ins.chequea(tt);}
	}
	
	public String generateCode() {
		String s = "(module \r\n"
				+ "(type $_sig_i32i32i32 (func (param i32 i32 i32) ))\r\n"
				+ "(type $_sig_i32ri32 (func (param i32) (result i32)))\r\n"
				+ "(type $_sig_i32 (func (param i32)))\r\n"
				+ "(type $_sig_ri32 (func (result i32)))\r\n"
				+ "(type $_sig_void (func ))\r\n"
				+ "(import \"runtime\" \"exceptionHandler\" (func $exception (type $_sig_i32)))\r\n"
				+ "(import \"runtime\" \"print\" (func $print (type $_sig_i32)))\r\n"
				+ "(import \"runtime\" \"read\" (func $read (type $_sig_ri32)))"+
				"(memory 2000)\r\n" +
				"(global $SP (mut i32) (i32.const 0)) \n" +
				"(global $MP (mut i32) (i32.const 0)) \n" +
				"(start $init) \r\n"
				+ " (func $reserveStack (param $size i32)\r\n"
				+ "   (result i32)\r\n"
				+ "   get_global $MP\r\n"
				+ "   get_global $SP\r\n"
				+ "   set_global $MP\r\n"
				+ "   get_global $SP\r\n"
				+ "   get_local $size\r\n"
				+ "   i32.add\r\n"
				+ "   set_global $SP\n"
				+ ")\n "
				
				+ "(func $freeStack (type $_sig_void)\r\n"
				+ "   get_global $MP\r\n"
				+ "   i32.load\r\n"
				+ "   i32.load offset=4\r\n"
				+ "   set_global $SP\r\n"
				+ "   get_global $MP\r\n"
				+ "   i32.load\r\n"
				+ "   set_global $MP   \r\n"
				+ ")\n"
				
				+ "(func $write \n"
				+ "   get_global $SP\n"
				+ "   i32.const 8\n"
				+ "   i32.add\n"
				+ "   i32.load\n"
				+ "   call $print\n"
				+ ")\n\n";
			
		if (dt != null) {s += dt.generateCode();}
		if (df != null) {s += df.generateCode();}
		s += "(func $init \n" + "(local $localsStart i32)\r\n"
				+ "(local $temp i32) \n";
		if (ins!= null) {
			int esp = 0;
			esp = ins.calcular_espacio(esp);
			s += "i32.const " + (esp*4 + 8) +"\n"  ;
			s += "call $reserveStack\nset_local $temp\r\n"
					+ "   get_global $MP\r\n"
					+ "   get_local $temp\r\n"
					+ "   i32.store\r\n"
					+ "   get_global $MP\r\n"
					+ "   get_global $SP\r\n"
					+ "   i32.store offset=4\r\n"
					+ "   get_global $MP\r\n"
					+ "   i32.const 8\r\n"
					+ "   i32.add\r\n"
					+ "   set_local $localsStart\n";
			s += ins.generateCode();
			s += "call $freeStack\n";
		}
		s += ")\r\n" + 
				"(export \"init\" (func $init)) \r\n )";
		return s;
	}
	@Override
	public int getDelta() {
		return 0;
	}

}
