package ast;

import java.util.Map;

public class EParams extends E{
	private Valor param1;
	private EParams param2;
	
	public EParams(Valor param1, EParams param2) {
		this.param1 = param1;
		this.param2 = param2;
	}
	public EParams(Valor param1) {
		this.param1 = param1;
	}
	
	public String param1() {return this.param1.toString();}
	public EParams params() {return this.param2;}
	
	public String toString() {
		String s = null;
		s = "params("+param1()+")";
		if (param2 != null) {
		   s = s +","+params().toString();
		}
		return s;
	}
	
	
	public KindE kind() {
		return KindE.PARAMETRO;
	}
	
	public void bind(TablaSimbolos ts) {
		param1.bind(ts);
		if(param2 != null) {
			param2.bind(ts);
		}
	}
	public void chequea(Map<String, String> tt) {
		param1.chequea(tt);
		if(param2 != null) {
			param2.chequea(tt);
		}
	}
	
	public String tipos() {
		String s = param1.type();
		if(param2 != null) {
			s = s + ", " + param2.type();
		}
		return s;
	}
	
	public String type() {
		return param1.type();
	}
	
	public String generateCode() {
		String s = "";
		s += param1.generateCode();
		
		if(param2 != null) {
			s += param2.generateCode();
		}
		
		return s;
	}
	
	public String generateCode_dir() {
		return ((E) param1).generateCode_dir();
		
	}
	
}
