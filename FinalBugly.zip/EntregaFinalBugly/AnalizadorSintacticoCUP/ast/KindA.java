package ast;

public enum KindA {
	SUBAR
}
