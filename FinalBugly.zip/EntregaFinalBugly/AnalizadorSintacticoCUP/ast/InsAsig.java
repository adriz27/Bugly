package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class InsAsig extends I {
	private E var;
	private Valor valor;
	public InsAsig( E var, Valor valor ) {
		this.var = var;
		this.valor = valor;
	}
	public E var() {return this.var;}
	public Valor valor() {return this.valor;}
	
	public String toString() {
		return "asig("+var.toString()+","+valor().toString()+")";
	}

	public KindI kind() {
		return KindI.ASIG;
	}
	public void bind(TablaSimbolos ts) {
		var.bind(ts);
		valor.bind(ts);
	}
	public void chequea(Map<String, String> tt) {
		valor.chequea(tt);
		var.chequea(tt);
		if(!valor.type().equals(var.type())) {
			System.out.println("Error en asignaci�n: El tipo de la variable (" + var.type() + ") y del valor asignado (" + valor.type() + ") no coinciden");
			GestionErroresTiny.error_tipo();
		}
	}
	public String generateCode() {
		String s = "";
		s += var.generateCode_dir();
		s += valor.generateCode();
		s += "i32.store\n";
		return s;
	}
}
