package ast;

import java.util.Map;

public class InsReturn extends I{
	private Valor v;
	public InsReturn(Valor v) {
		this.v = v;
	}

	public Valor v() {return v;}
	
	public String toString() {
		return "return("+v().toString()+")";
	}
	
	public KindI kind() {
		return KindI.RETURN;
	}
	public void bind(TablaSimbolos ts) {
		v.bind(ts);
	}
	public void chequea(Map<String, String> tt) {
		v.chequea(tt);
	}
	
	public String retorno() {
		return v.type();
	}

	
	public String generateCode() {
		return v.generateCode();
	}
	
}