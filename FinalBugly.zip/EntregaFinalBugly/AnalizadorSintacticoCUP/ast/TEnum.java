package ast;

import java.util.Map;

public class TEnum extends T{
	private Id id;
	private TEnumElemBin lista;
	
	public TEnum( Id id, TEnumElemBin lista) {
		this.id = id;
		this.lista = lista;
	}
	public String id() {return this.id.toString();}
	public TEnumElemBin lista() {return this.lista;}
		
	public String toString() {
		return "enum("+id()+",("+lista().toString()+"))";
	}

	public KindT kind() {
		return KindT.ENUM;
	}
	
	public void bind(TablaSimbolos ts) {
		ts.insertaId(id, this);
		lista.bind_enum(ts, this);
	}
	
	public void chequea(Map<String, String> tt) {
		tt.put(id.id(), "enum");
		lista.chequea(tt);
	}
	
	public String type() {
		return id.id();
	}
	
	public String tipoSI() {
		return type();
	}
}