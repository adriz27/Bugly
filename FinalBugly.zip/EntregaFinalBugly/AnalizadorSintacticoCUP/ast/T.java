package ast;

public abstract class T implements ASTNode {
	public abstract KindT kind();
    public String id() {throw new UnsupportedOperationException("id");} 
    public String size() {throw new UnsupportedOperationException("size");} 
    public I campo1() {throw new UnsupportedOperationException("campo");} 
    public TCampoBin campo2() {throw new UnsupportedOperationException("campo");}
    public String elem1() {throw new UnsupportedOperationException("elemnto enumerado");} 
	public TEnumElemBin elem2() {throw new UnsupportedOperationException("elementos enumerado");}
    
    
    public NodeKind nodeKind() {return NodeKind.TDEFINICION;}
    //public String toString() {return "";}
    //public void bind(TablaSimbolos ts) {}
    //public String type() {return null;}
    
    public String generateCode() {return "";}
    public int getDelta() {return 0;}
	public String tipoSI() {
		
		return null;
	}
}
