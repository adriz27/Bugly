package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class EUna extends E {
   private E opnd1;
   private KindE kind;
   public EUna(KindE kinde, E opnd1) {
     this.opnd1 = opnd1;
     this.kind = kinde;
   }
   public E opnd1() {return opnd1;}
   public KindE kind() {return kind;}
   
   public String toString() {
	   String s = null;
	   switch(this.kind) {
	   
	   case NOT:
		   s= "not("+opnd1().toString()+")";
		   break;
	   case ALMOHADILLA:
			s= "indir("+opnd1().toString()+")";
			break;
	   case AMPERSAND:
			s= "direc("+opnd1().toString()+")";
			break;
		default:
			break;
	   }
	return s;
   }
	
	public void bind(TablaSimbolos ts) {
		opnd1.bind(ts);
	}
	public void chequea(Map<String, String> tt) {
		opnd1.chequea(tt);
		if(kind == KindE.NOT && !opnd1.type().equals("bool")) {
			System.out.println("Error en expresi�n booleana: El operando debe ser una expresi�n booleana");
			GestionErroresTiny.error_tipo();
		}
		else if(kind == KindE.ALMOHADILLA && opnd1.type().charAt(0) != 'p') {
			System.out.println("Error: No es un puntero");
			GestionErroresTiny.error_tipo();
		}
	}
	
	public String type() {
		if(kind == KindE.NOT) {
			return "bool";
		}
		else if(kind == KindE.AMPERSAND) {
			return "p " + opnd1.type();
		}
		else {
			return opnd1.type().substring(2);
		}
	}
	
	public String generateCode() {
		String s = "";
		switch(this.kind) {
		   case NOT:
			   s += opnd1.generateCode();
			   s += "i32.eqz\n";
			   break;
		   case ALMOHADILLA:
			   
				break;
		   case AMPERSAND:
			   //s += opnd1.generateCode_dir();
				break;
			default:
				break;
		   }
		return s;
	}
}