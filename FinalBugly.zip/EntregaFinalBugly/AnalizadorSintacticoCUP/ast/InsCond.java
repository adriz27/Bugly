package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class InsCond extends I{
	private E e;
	private I ins1;
	private I ins2;
	public InsCond(E e, I ins1, I ins2) {
		this.e = e;
		this.ins1 = ins1;
		this.ins2 = ins2;
	}

	public E e() {return e;}
	public I ins1() {return ins1;}
	public I ins2() {return ins2;}
	
	public String toString() {
		String s = "ifthenelse("+e().toString()+",(";
		if (ins1 != null) {
			s = s + ins1().toString();
		}
		s = s + "),(";
		if (ins2 != null) {
			s = s + ins2().toString();
		}
		s = s + "))";
		return s;
	}
	public KindI kind() {
		return KindI.COND;
	}

	public void bind(TablaSimbolos ts) {
		e.bind(ts);
		if (ins1 != null) {
			ts.abreBloque();
			ins1.bind(ts);
			ts.cierraBloque();
		}
		if (ins2 != null) {
			ts.abreBloque();
			ins2.bind(ts);
			ts.cierraBloque();
		}
		
	}
	public void chequea(Map<String, String> tt) {
		e.chequea(tt);
		if(!(e.type().equals("bool"))) {
			System.out.println("Error en instrucci�n condicional: La condici�n deber�a ser una expresi�n booleana");
			GestionErroresTiny.error_tipo();
		}
		else {
			if(ins1 != null) {
				ins1.chequea(tt);
			}
			if(ins2 != null) {
				ins2.chequea(tt);
			}
		}
	}
	
	public String generateCode() {
		String s = e.generateCode();
		s += "if\n";
		if(ins1 != null) {
			s += ins1.generateCode();
		}
		s += "else\n";
		if(ins2 != null) {
			s += ins2.generateCode();
		}
		s += "end\n";
		return s;
	}
}
