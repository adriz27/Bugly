package ast;

import java.util.Map;

public class IBin extends I{
	private I i1;
	private I i2;
	public IBin(I i1, I i2) {
		this.i1 = i1;
		this.i2 = i2;
	}
	 public String toString() {
		 String s = null;
		 s =  i1.toString();
		 if (i2 != null) {
		   s= s +","+i2.toString();
		 }
		 return s;
	   }
	public KindI kind() {
		return null;
	}
	
	public void bind(TablaSimbolos ts) {
		i1.bind(ts);
		if(i2 != null) {
			i2.bind(ts);
		}
	}
	public void chequea(Map<String, String> tt) {
		i1.chequea(tt);
		if(i2 != null) {
			i2.chequea(tt);
		}
	}
	
	public String retorno() {
		if(i2 == null) {return i1.retorno();}
		else {return i2.retorno();}
	}
	public String generateCode() {
		String s = i1.generateCode();
		if(i2 != null) {
			s +=i2.generateCode();
		} 
		return s;
	}
	@Override
	public int calcular_espacio(int e) {
		e = i1.calcular_espacio(e);
		if(i2 != null) {
			e = i2.calcular_espacio(e);
		}
		return e;
	}
}
