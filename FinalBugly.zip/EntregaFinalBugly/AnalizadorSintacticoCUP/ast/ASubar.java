package ast;

public class ASubar extends A{
	private Valor v;
	private A arr;
	public ASubar(Valor v, A s) {
		this.v = v;
		this.arr = s;
	}
	
	public ASubar(Valor v) {
		this.v = v;
	}

	public Valor val() {return v;}
	public A arr() {return arr;}    
	 public String toString() {
		 String s = null;
		 if (arr() != null) {
		   s= val().toString()+","+arr().toString();
		 }
		 else {
		   s =  val().toString();
		 }
		 return s;
	   }
	
	public KindA kind() {
		return KindA.SUBAR;
	}

	public void bind(TablaSimbolos ts) {
		v.bind(ts);
		if (arr != null) {
			arr.bind(ts);
		}
	}

}
