package ast;

public enum KindTipo {
	TINT, TBOOL, ID
}
