package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class TArray extends T{
	private Id id;
	private Tipo t;
	private Num n;
	
	public TArray( Id id, Tipo t, Num n) {
		this.id = id;
		this.t = t;
		this.n = n;
	}
	public String id() {return this.id.toString();}
	public String subt() {return t.toString();}
	public String n() {return this.n.toString();}
	
	public String type() {return "array " + n + " " + t.tipo();}
	
	public String toString() {
		return "array("+id()+","+ t.toString() +","+n()+")";
	}

	public KindT kind() {
		return KindT.ARRAY;
	}
	
	public void bind(TablaSimbolos ts) {
		if(!t.getT().equals("int") && !t.getT().equals("bool") && ts.buscaSt(t.getT()) == null) {
			System.out.println("Tipo no definido: " + t.getT());
			GestionErroresTiny.error_bind();
		}
		ts.insertaId(id, this);
	}
	public void chequea(Map<String, String> tt) {
		String tipo = t.tipo();
		if(tt.containsKey(tipo)) {tipo = tt.get(tipo);}
		tt.put(id.id(), "array " + n + " " + tipo);
	}
}
