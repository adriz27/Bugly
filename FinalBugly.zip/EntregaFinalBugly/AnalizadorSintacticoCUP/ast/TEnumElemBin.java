package ast;

import java.util.Map;

public class TEnumElemBin extends T {
	private Id elem1;
	private TEnumElemBin elem2;
	private ASTNode n;
	
	public TEnumElemBin(Id elem1, TEnumElemBin elem2) {
		this.elem1 = elem1;
		this.elem2 = elem2;
	}
	public TEnumElemBin(Id elem1) {
		this.elem1 = elem1;
	}
	public String elem1() {return elem1.toString();}
	public TEnumElemBin elem2() {return elem2;}
	 public String toString() {
		 String s = null;
		 if (elem2() != null) {
		   s = elem1()+","+elem2.toString();
		 }
		 else {
		   s =  elem1();
		 }
		 return s;
	   }

	public KindT kind() {
		return KindT.ELEMENUM;
	}
	
	public void bind_enum(TablaSimbolos ts, ASTNode n) {
		ts.insertaId(elem1, n);
		if(elem2 != null) {
			elem2.bind_enum(ts, n);
		}
	}
	
	public void chequea(Map<String, String> tt) {
		
	}
	
	public String type() {
		return n.type();
	}
	
	public void bind(TablaSimbolos ts) {
		
	}
	
	
}
