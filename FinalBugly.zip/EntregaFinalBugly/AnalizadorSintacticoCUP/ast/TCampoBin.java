package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class TCampoBin extends T{
	private Tipo t1;
	private Id id1;
	private int delta;
	private TCampoBin campo;
	
	public TCampoBin(Tipo t1,Id id1, TCampoBin campo) {
		this.t1 = t1;
		this.id1 = id1;
		this.campo = campo;
	}
	public TCampoBin(Tipo t1,Id id1) {
		this.t1 = t1;
		this.id1 = id1;
	}
	  public String id() {return id1.toString();}
	  public TCampoBin campo() {return campo;}
	  
	 public String toString() {
		 String s = "campo("+ t1.toString() + "," + id() + ")";
		 if (campo() != null) {
		   s = s + campo().toString();
		 }
		 
		 return s;
	   }
	public KindT kind() {
		return KindT.CAMPO;
	}
	
	public void bind(TablaSimbolos ts) {
		if(!t1.getT().equals("int") && !t1.getT().equals("bool") && ts.buscaSt(t1.getT()) == null) {
			System.out.println("Tipo no definido: " + t1.getT());
			GestionErroresTiny.error_bind();
		}
		ts.insertaId(id1, this);
		if (campo() != null) {
			campo.bind(ts);
		}
	}
	
	public void chequea(Map<String, String> tt) {
		if(tt.containsKey(t1.tipo())) { t1.updateTipo(tt.get(t1.tipo())); }
		tt.put(id1.id(), "campo " + t1.tipo());
		if(campo != null) {
			campo.chequea(tt);
		}
	}
	
	public String type() {
		return "campo " + t1.toString();
	}
	
	public String tipos() {
		String s = t1.tipo();
		if(campo != null) {
			s = s + ", " + campo.tipos();
		}
		return s;
	}

	
	public int calcular_espacio(int e){
		int aux = 0;
		delta = e;
		aux = e + Tipo.espacio(t1.tipo());
		if(campo != null) {
			aux = campo.calcular_espacio(aux);
		}
		return aux;
	}
	public int getDelta() {
		return delta;
	}
	
}
