package ast;
import java.util.ArrayList;
import java.util.List;

public class TablaSimbolos {
	private List<Tabla> pilaTabla;
	
	public TablaSimbolos() {
		pilaTabla = new ArrayList<Tabla>();
	}
		
	public void abreBloque(){
		Tabla nueva = new Tabla();
		pilaTabla.add(nueva);
	}
	
	public void cierraBloque(){
		pilaTabla.remove(pilaTabla.size()-1);
	}
	
	public void insertaId(Id id, ASTNode nodo) {
		pilaTabla.get(pilaTabla.size()-1).setIdNode(id.id(), nodo);
	}
	
	public ASTNode buscaId(Id id) {
		ASTNode n = null;
		int i = pilaTabla.size();
		while (n == null && i > 0) {
			i--;
			n = pilaTabla.get(i).getNode(id.id());
		}
		return n;
	}
	
	public ASTNode buscaId_ambito(Id id) {
		return pilaTabla.get(pilaTabla.size()-1).getNode(id.id());
	}

	public ASTNode buscaSt(String tipo) {
		ASTNode n = null;
		int i = pilaTabla.size();
		while (n == null && i > 0) {
			i--;
			n = pilaTabla.get(i).getNode(tipo);
		}
		return n;
	}
	
}


