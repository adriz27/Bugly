package ast;

import java.util.Map;

import errors.GestionErroresTiny;

public class InsIfthen extends I{
	private E e;
	private I ins;
	public InsIfthen(E e, I ins) {
		this.e = e;
		this.ins = ins;
	}

	public E e() {return e;}
	public I ins() {return ins;}
	
	public String toString() {
		String s = "ifthen("+e().toString()+",(";
		if (ins != null) {
			s = s + ins().toString();
		}
		s = s + "))";
		return s;
	}
	public KindI kind() {
		return KindI.IFTHEN;
	}

	public void bind(TablaSimbolos ts) {
		e.bind(ts);
		if (ins != null) {
			ts.abreBloque();
			ins.bind(ts);
			ts.cierraBloque();
		}
	}
	public void chequea(Map<String, String> tt) {
		e.chequea(tt);
		if(!(e.type().equals("bool"))) {
			System.out.println("Error en instrucci�n condicional: La condici�n deber�a ser una expresi�n booleana");
			GestionErroresTiny.error_tipo();
		}
		else {
			if(ins != null) {
				ins.chequea(tt);
			}
		}
	}
	
	public String generateCode() {
		String s = e.generateCode();
		s += "if\n";
		if(ins != null) {
			s += ins.generateCode();
		}
		s += "end\n";
		return s;
	}
}
