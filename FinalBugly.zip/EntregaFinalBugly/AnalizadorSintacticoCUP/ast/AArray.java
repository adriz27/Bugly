package ast;

public class AArray extends A{
	private A a;
	
	public AArray(A a) {
		this.a = a;
	}
	public AArray() {
	}
	public String toString() {
		if(a != null) {
			return "array("+a.toString()+")";
		}
		else {
			return "array()";
		}
	}
	public KindA kind() {
		return null;
	}
	public void bind(TablaSimbolos ts) {
		if(a != null) {
			a.bind(ts);
		}
	}
}
