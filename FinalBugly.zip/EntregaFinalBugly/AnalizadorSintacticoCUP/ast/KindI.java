package ast;

public enum KindI {
	ASIG, DECL, RETURN, IFTHEN, COND, BUCLE, CALL
}

//IGUAL corresponde ASIG