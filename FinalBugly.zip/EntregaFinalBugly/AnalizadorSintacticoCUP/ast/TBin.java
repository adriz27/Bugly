package ast;

import java.util.Map;

public class TBin extends T{
	private T t1;
	private T t2;
	public TBin(T t1, T t2) {
		this.t1 = t1;
		this.t2 = t2;
	}
	public TBin(T t1) {
		this.t1 = t1;
	}
	 public String toString() {
		 String s = null;
		 if (t2 != null) {
		   s= t1.toString() + ", " + t2.toString();
		 }
		 else {
		   s =  t1.toString();
		 }
		 return s;
	   }
	 
	public KindT kind() {
		return null;
	}
	
	public void bind(TablaSimbolos ts) {
		t1.bind(ts);
		if(t2 != null) {
			t2.bind(ts);
		}
	}
	
	public void chequea(Map<String, String> tt) {
		t1.chequea(tt);
		if(t2 != null) {
			t2.chequea(tt);
		}
	}
	
	public String type() {
		return null;
	}
	
	public String generateCode() {
		String s = t1.generateCode();
		if (t2!=null) {
			s+= t2.generateCode();
		}
		return s;
		
	}
}
