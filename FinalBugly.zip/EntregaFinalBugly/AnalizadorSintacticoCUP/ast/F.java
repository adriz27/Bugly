package ast;

public abstract class F implements ASTNode {
	//public abstract KindT kind(); No hace falta entiendo
    public String id() {throw new UnsupportedOperationException("id");} 
    public String tipo() {throw new UnsupportedOperationException("tipo");} 
    public FArg argumentos() {throw new UnsupportedOperationException("argumentos");} 
    public I instrucciones() {throw new UnsupportedOperationException("instrucciones");} 
    public NodeKind nodeKind() {return NodeKind.FDEFINICION;}
    public abstract void prebind(TablaSimbolos ts);
    //public String toString() {return "";}
    //public void bind(TablaSimbolos ts) {}
    public void chequea(Tabla tt) {}
    //public String type() {return null;}
    //public String generateCode() {return null;}
    public int getDelta() {return 0;}
}


