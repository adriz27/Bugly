package ast;

import java.util.Map;

public class Bool extends E {
  private String v;
  public Bool(String v) {
   this.v = v;
  }
  public String num() {return v;}
  public KindE kind() {return KindE.BOOLEANO;}   
  public String toString() {return v;}
  public void bind(TablaSimbolos ts) {}
  public void chequea(Map<String, String> tt) {}
  
  public String type() {		
		return "bool";
	}

  public String generateCode() {
	  String n = "0";
	  if (v.equals("true")) {n = "1";}
	  return "i32.const " + n + "\n";
  }
}
