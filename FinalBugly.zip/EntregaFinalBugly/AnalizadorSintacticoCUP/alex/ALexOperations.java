package alex;
import asint.ClaseLexica;

public class ALexOperations {
  private AnalizadorLexicoTiny alex;
  public ALexOperations(AnalizadorLexicoTiny alex) {
   this.alex = alex;   
  }
  
  public UnidadLexica unidadDefFuncion(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.DEFFUNCION, alex.lexema());
}
public UnidadLexica unidadDefTipo(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.DEFTIPO, alex.lexema());
}
public UnidadLexica unidadEnd(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.END, alex.lexema());
}
public UnidadLexica unidadIf(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.IF, alex.lexema());
}
public UnidadLexica unidadThen(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.THEN, alex.lexema());
}
public UnidadLexica unidadElse(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.ELSE, alex.lexema());
}
public UnidadLexica unidadWhile(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.WHILE, alex.lexema());
}
public UnidadLexica unidadDo(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.DO, alex.lexema());
}
public UnidadLexica unidadReturn(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.RETURN, alex.lexema());
}
public UnidadLexica unidadStruct(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.STRUCT, alex.lexema());
}
public UnidadLexica unidadEnum(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.ENUM, alex.lexema());
}
public UnidadLexica unidadBooleano(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.BOOLEANO, alex.lexema());
}
public UnidadLexica unidadVoid(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.VOID, alex.lexema());
}
public UnidadLexica unidadtInt(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.TINT, alex.lexema());
}
public UnidadLexica unidadtBool(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.TBOOL, alex.lexema());
}
public UnidadLexica unidadEnt(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.ENT, alex.lexema());
}
public UnidadLexica unidadSuma(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.SUMA, alex.lexema());
}
public UnidadLexica unidadResta(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.RESTA, alex.lexema());
}
public UnidadLexica unidadMul(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.MUL, alex.lexema());
}
public UnidadLexica unidadDiv(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.DIV, alex.lexema());
}
public UnidadLexica unidadMod(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.MOD, alex.lexema());
}
public UnidadLexica unidadPot(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.POT, alex.lexema());
}
public UnidadLexica unidadNot(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.NOT, alex.lexema());
}
public UnidadLexica unidadAnd(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.AND,alex.lexema());
}
public UnidadLexica unidadOr(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.OR,alex.lexema());
}
public UnidadLexica unidadIgualdad(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.IGUALDAD, alex.lexema());
}
public UnidadLexica unidadDistinto(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.DISTINTO, alex.lexema());
}
public UnidadLexica unidadMayorIgual(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.MAYORIGUAL, alex.lexema());
}
public UnidadLexica unidadMenorIgual(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.MENORIGUAL, alex.lexema());
}
public UnidadLexica unidadMayor(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.MAYOR, alex.lexema());
}
public UnidadLexica unidadMenor(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.MENOR, alex.lexema());
}
public UnidadLexica unidadApar(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.APAR, alex.lexema());
}
public UnidadLexica unidadCpar(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.CPAR, alex.lexema());
}
public UnidadLexica unidadIgual(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.IGUAL, alex.lexema());
}
public UnidadLexica unidadPtocoma(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.PTOCOMA, alex.lexema());
}
public UnidadLexica unidadPunto(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.PUNTO, alex.lexema());
}
public UnidadLexica unidadComa(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.COMA, alex.lexema());
}
public UnidadLexica unidadAcorch(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.ACORCH, alex.lexema());
}
public UnidadLexica unidadCcorch(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.CCORCH, alex.lexema());
}
public UnidadLexica unidadAmpersand(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.AMPERSAND, alex.lexema());
}
public UnidadLexica unidadAlmohadilla(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.ALMOHADILLA, alex.lexema());
}
public UnidadLexica unidadId(){
      return new UnidadLexica(alex.fila(), alex.columna(), ClaseLexica.ID, alex.lexema());
}
public UnidadLexica unidadEof() {
    return new UnidadLexica(alex.fila(),alex.columna(),ClaseLexica.EOF); 
 }
	  
}
